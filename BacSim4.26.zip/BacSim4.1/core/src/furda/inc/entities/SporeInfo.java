package furda.inc.entities;

//A class to hold info about the positions of the spore
//Intent is to make it so that each bacteria does not need to do multiple calculations for each spore. Only one will be needed

public class SporeInfo {

}
