package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

import java.util.concurrent.ThreadLocalRandom;

public class Spore extends Particles{

    private BacteriaGeneral myParent;

    private int currentMove;
    private int movingDirection;

    //Animation test
    private TextureRegion[] regions = new TextureRegion[8];
    private int roll;
    private int count;

    //Spore deletion testing here
    //public static int sporeCount;

    public Spore(float x, float y, EntityType type, GameMap map, BacteriaGeneral parent) {
        super(x, y, type, map);
        myParent = parent;
        if (myParent.getBacteriaType() == EntityType.BACTERIABLUE){
            image = new Texture("BlueSpore.png");
            regions[0] = new TextureRegion(image, 0, 0, 11,13);
            regions[1] = new TextureRegion(image, 0, 0, 11,13);
            regions[2] = new TextureRegion(image, 11, 0, 11,13);
            regions[3] = new TextureRegion(image, 11, 0, 11,13);
            regions[4] = new TextureRegion(image, 0, 13, 11,13);
            regions[5] = new TextureRegion(image, 0, 13, 11,13);
            regions[6] = new TextureRegion(image, 11, 13, 11,13);
            regions[7] = new TextureRegion(image, 11, 13, 11,13);

        }else{
            image = new Texture("RedSpore.png");
            regions[0] = new TextureRegion(image, 0, 0, 11,13);
            regions[1] = new TextureRegion(image, 11, 0, 11,13);
            regions[2] = new TextureRegion(image, 22, 0, 11,13);
            regions[3] = new TextureRegion(image, 0, 13, 11,13);
            regions[4] = new TextureRegion(image, 11, 13, 11,13);
            regions[5] = new TextureRegion(image, 22, 13, 11,13);
            regions[6] = new TextureRegion(image, 0, 26, 11,13);
            regions[7] = new TextureRegion(image, 0, 26, 11,13);
        }
        SPEED = 120;
        //setID(sporeCount);
        //sporeCount+=1;
        movingDirection = ThreadLocalRandom.current().nextInt(1, 5);
        currentMove = movingDirection;
    }

    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
        //System.out.println("Spore: " + getID() + " currently active.");
        //Make random movement so that it is more likely to move away from its parent entity



        //Here we use negative speed as we are moving char to the left
        /*Direction = ThreadLocalRandom.current().nextInt(1, 100);
        if (Direction < 70){
            currentMove = movingDirection;
        }else if (Direction >= 70 && Direction < 85){
            if(movingDirection == 4){
                currentMove = 1;
            }else {
                currentMove = movingDirection + 1;
            }
        }else if (Direction >= 85 && Direction < 100){
            if(movingDirection == 1){
                currentMove = 4;
            }else {
                currentMove = movingDirection - 1;
            }
        }else{
            if(movingDirection == 3){
                currentMove = 1;
            }else if(movingDirection == 4){
                currentMove = 2;
            }else {
                currentMove = movingDirection + 2;
            }
        }

        //1 is down
        if(currentMove == 1) {
            moveY(-SPEED * deltaTime);
            lastD1 = 3;
        }

        //2 is right
        if(currentMove == 2) {
            moveX(SPEED * deltaTime);
            lastD2 = 4;
        }

        //3 is up
        if(currentMove == 3) {
            moveY(SPEED * deltaTime);
            lastD1 = 1;
        }

        //4 is left
        if(currentMove == 4) {
            moveX(-SPEED * deltaTime);
            lastD2 = 2;
        }

        if (map.doesRectCollideWithMap((this.pos.x + (SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap((this.pos.x + (-SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (SPEED * deltaTime)), 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (-SPEED * deltaTime)), 32,32)){

            movingDirection+=2;
            if(movingDirection == 5)
                movingDirection = 1;
            if(movingDirection == 6)
                movingDirection=2;
        }*/

        /*Direction = ThreadLocalRandom.current().nextInt(1, 100);

        //Here we use negative speed as we are moving char to the left

        if (Direction < 90){
            currentMove = currentMove;
        }else if (Direction >93 && Direction < 96){
            if(currentMove == 4){
                currentMove = 1;
            }else {
                currentMove += 1;
            }
        }else if (Direction > 95 && Direction < 98){
            if(currentMove == 1){
                currentMove = 4;
            }else {
                currentMove -= 1;
            }
        }else{
            if(currentMove == 3){
                currentMove = 1;
            }else if(currentMove == 4){
                currentMove = 2;
            }else {
                currentMove += 2;
            }
        }

        //1 is down
        if(currentMove == 1) {
            moveY(-SPEED * deltaTime);
            lastD1 = 3;
        }

        //2 is right
        if(currentMove == 2) {
            moveX(SPEED * deltaTime);
            lastD2 = 4;
        }

        //3 is up
        if(currentMove == 3) {
            moveY(SPEED * deltaTime);
            lastD1 = 1;
        }

        //4 is left
        if(currentMove == 4) {
            moveX(-SPEED * deltaTime);
            lastD2 = 2;
        }

        if (map.doesRectCollideWithMap((this.pos.x + (SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap((this.pos.x + (-SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (SPEED * deltaTime)), 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (-SPEED * deltaTime)), 32,32)){
            currentMove+=2;
            if(currentMove == 5)
                currentMove = 1;
            if(currentMove == 6)
                currentMove=2;
        }*/




        /*Direction = ThreadLocalRandom.current().nextInt(1, 5);
        //Here we use negative speed as we are moving char to the left

        while (Direction == lastD1 || Direction == lastD2)
            Direction = ThreadLocalRandom.current().nextInt(1, 5);

        //1 is down
        if(Direction == 1) {
            moveY(-SPEED * deltaTime);
            lastD1 = 3;
        }

        //2 is right
        if(Direction == 2) {
            moveX(SPEED * deltaTime);
            lastD2 = 4;
        }

        //3 is up
        if(Direction == 3) {
            moveY(SPEED * deltaTime);
            lastD1 = 1;
        }

        //4 is left
        if(Direction == 4) {
            moveX(-SPEED * deltaTime);
            lastD2 = 2;
        }

        if (map.doesRectCollideWithMap((this.pos.x + (SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap((this.pos.x + (-SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (SPEED * deltaTime)), 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (-SPEED * deltaTime)), 32,32)){
            lastD1 = 0;
            lastD2 = 0;
        }*/

    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 8){
            roll = 0;
        }
        //System.out.println("I get called");
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        batch.draw(regions[roll], pos.x, pos.y, getWidth(), getHeight());
        //super.render(batch);
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        //Here is replication (or maybe original?)

    }

    boolean checkParent(BacteriaGeneral parent){
        if (myParent == parent){
            return  true;
        }
        return false;
    }

    public BacteriaGeneral getMyParent(){
        return myParent;
    }

}
