package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import furda.inc.world.GameMap;
import com.badlogic.gdx.graphics.g2d.Animation;

import java.util.ArrayList;

public abstract class BacteriaGeneral extends Entity {

    private Vector3 mousePos; // Position of the mouse, used for testing bindings

    Animation[] rolls; // The animation roll for movement of the bacteria
    private int roll; // The specific slide that the bacteria is on


    private int sporeCount;
    private int ID;

    //Spore test idea
    //protected ArrayList<Spore> myspores;
    private ArrayList<Spore> myspores;
    //private Spore[] myspores = new Spore[5];
    //FOR TESTING

    //For the binding points on a specific bacteria
    private boolean topRight, topLeft, bottomRight, bottomLeft;
    private boolean allBound;
    private boolean redEnzymeBound;

    //For final position of bacteria
    private boolean inPlaceY;
    private boolean inPlaceX;

    //Boolean to check if a bacteria has been interacted with by a blocker (antibiotics/garlic)
    private boolean blockerBound;
    private boolean removed;





    public BacteriaGeneral(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        myspores = new ArrayList<Spore>();

        //Spore test idea
        setSporeCount(1);
        myspores.add(new Spore(this.getX(),this.getY(),EntityType.SPORE,map,this));


        topLeft = false;
        topRight = false;
        bottomLeft = false;
        bottomRight = false;
        allBound = false;
        blockerBound = false;
        removed = false;
        inPlaceX = false;
        inPlaceY = false;
        redEnzymeBound = false;
    }

    @Override
    public void update(float deltaTime, float gravity){
        //super.update(deltaTime, gravity);
        //Spores being updated twice
        //int count = 0;
        for(Spore spore : myspores){
            //count = count +1;
            spore.update(deltaTime, gravity);
            //System.out.println("Bacteria " + getID() + " showing spore " + count);
        }
        if(!allBound) {
            checkForm();
        }
        if(topRight && topLeft && bottomRight && bottomLeft){
            allBound = true;
            //image = new Texture("badlogic.jpg");

        }
        /*if(getSporeCount() == 2){
            image = new Texture("BlueBacTemp1.jpg");
        }
        if(getSporeCount() == 3){
            image = new Texture("BlueBacTemp2.jpg");
        }
        if(getSporeCount() == 4){
            image = new Texture("BlueBacTemp3.jpg");
        }*/
        /*if(blockerBound){
            image = new Texture("BlockedBacTemp.jpg");
        }*/
        /*else{

            if(topLeft){
                System.out.println(getID() + " TL");
            }
            if(topRight){
                System.out.println(getID() + " TR");
            }
            if(bottomLeft){
                System.out.println(getID() + " BL");
            }
            if(bottomRight){
                System.out.println(getID() + " BR");
            }
        }*/

    }


    @Override
    public void render(SpriteBatch batch) {
        //batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
        //Here is replication (or maybe original?)
        for(Spore spore : myspores){
            spore.render(batch);
            //batch.draw(spore.getImage(), spore.getX(), spore.getY(), spore.getWidth(), spore.getHeight());
        }
    }




    public int getSporeCount(){ return sporeCount;}
    public void setSporeCount(int count){ sporeCount=count; }

    public ArrayList<Spore> getMyspores(){
        return myspores;
    }

    public abstract int getBacteriaCount();

    public EntityType getBacteriaType(){
        return this.type;
    };

    public int getID(){
        return ID;
    }

    public void setID(int set){
        ID = set;
    }

    public boolean getAllBound(){
        if(blockerBound){
            return false;
        }
        return allBound;
    }

    public void setInPlaceY(){
        inPlaceY = true;
    }
    public void setInPlaceX(){
        inPlaceX = true;
    }

    public boolean getInPlace(){
        if (inPlaceX && inPlaceY){
            return true;
        }else
            return false;
    }

    public void setBlockerBound(EntityType type){
        setSporeCount(0);
        blockerBound = true;
        topLeft = false;
        topRight = false;
        bottomLeft = false;
        bottomRight = false;
    }

    public void setRemoved(){
        setSporeCount(0);
        removed = true;
    }

    //Make check binding function that checks only one section of the Bacteria (E.g Bottom left only)
    public boolean checkBinding(float x, float y, EntityType type){
        if(redEnzymeBound && type == EntityType.REDENZYME){
            return false;
        }
        if(blockerBound && type != EntityType.WBC){
            return false;
        }
        if(removed){
            return false;
        }
        x = x + (type.getWidth()/2);
        y = y + (type.getHeight()/2);
        if ((x > this.pos.x && x < (this.pos.x + (this.getWidth()/2))) && (y > this.pos.y && y < (this.pos.y + (this.getHeight()/2)))){
            //System.out.println("Bottom left!");
            //System.out.println("Spore pos: ");
            //System.out.println("x: " + x);
            //System.out.println("y: " + y);
            //System.out.println("BotLeftX: " + this.pos.x + " - " + (this.pos.x + this.getWidth()/2));
            //System.out.println("BotLeftY: " + this.pos.y + " - " + (this.pos.y + this.getHeight()/2));
            if(type == EntityType.REDENZYME){
                return false;
            }
            if(type == EntityType.WBC){
                return true;
            }
            if (bottomLeft){
                return false;
            }
            //System.out.println("Bottom left! " + this.getID());
            bottomLeft = true;
            return true;
        }else if((x < this.posR.x && x > (this.posR.x - (this.getWidth()/2))) && (y > this.pos.y && y < (this.pos.y + (this.getHeight()/2)))){
            if(type == EntityType.REDENZYME){
                return false;
            }
            if(type == EntityType.WBC){
                return true;
            }
            if(bottomRight){
                return false;
            }
            //System.out.println("Bottom right! " + this.getID());
            bottomRight = true;
            return true;
        }else if((x > this.pos.x && x < (this.pos.x + (this.getWidth()/2))) && (y < this.posR.y && y > (this.posR.y - (this.getHeight()/2)))){
            if(type == EntityType.REDENZYME){
                redEnzymeBound = true;
                return true;
            }
            if(type == EntityType.WBC){
                return true;
            }
            if(topLeft){
                return false;
            }
            //System.out.println("Top left! " + this.getID());
            topLeft = true;
            return true;
        }else if((x < this.posR.x && x > (this.posR.x - (this.getWidth()/2))) && (y < this.posR.y && y > (this.posR.y - (this.getHeight()/2)))){
            if(type == EntityType.REDENZYME){
                return false;
            }
            if(type == EntityType.WBC){
                return true;
            }
            if(topRight){
                return false;
            }
            //System.out.println("Top right! " + this.getID());
            topRight = true;
            return true;
        }
        return false;
    }

    public boolean checkTopLeft(){
        return topLeft;
    }
    public boolean checkTopRight(){
        return topRight;
    }
    public boolean checkBottomLeft(){
        return bottomLeft;
    }
    public boolean checkBottomRight(){
        return bottomRight;
    }

    public abstract void checkForm();





}
