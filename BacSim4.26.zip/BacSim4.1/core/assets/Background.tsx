<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="Background" tilewidth="16" tileheight="16" tilecount="532" columns="38">
 <image source="Background.png" width="621" height="233"/>
</tileset>
