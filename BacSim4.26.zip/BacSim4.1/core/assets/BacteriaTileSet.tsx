<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="BacteriaTileSet" tilewidth="16" tileheight="16" tilecount="676" columns="26">
 <image source="Tiles1.png" width="417" height="417"/>
</tileset>
